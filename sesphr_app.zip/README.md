# Sesphr
This is an encrypted health record management system
